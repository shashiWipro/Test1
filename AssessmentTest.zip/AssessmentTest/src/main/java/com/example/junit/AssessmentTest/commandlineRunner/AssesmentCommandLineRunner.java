package com.example.junit.AssessmentTest.commandlineRunner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.example.junit.AssessmentTest.Entity.QuesAnsSet;
import com.example.junit.AssessmentTest.Entity.UserDetails;
import com.example.junit.AssessmentTest.dao.OnlineAssessmentDAO;
import com.example.junit.AssessmentTest.dao.UserDetailsDAO;

@Component
public class AssesmentCommandLineRunner implements CommandLineRunner {

   
	@Autowired
	private OnlineAssessmentDAO creditScoreDAO;
	
	@Autowired 
	private UserDetailsDAO userDao;
	
	
	@Override
	public void run(String... args) throws Exception {
		addQuestionAnswer();
		addUsers();
		UserDetails userDetails = userDao.findByEmailAndPassword("shashi@gmail.com","12345");
		System.out.println(userDetails.getFirstName());
		
		/*
		 * List<UserDetails> userList=userDao.findByUserType("Candidate");
		 * for(UserDetails ud:userList) {
		 * System.out.println(ud.getFirstName()+"\t"+ud.getLastName()+"\t"+ud.getEmail()
		 * +"\t"+ud.getUserType()); }
		 */
	}

	 
  public void addQuestionAnswer()
  {
	  //List<QuesAnsSet> listOfQA=new ArrayList<QuesAnsSet>();
	  
	  QuesAnsSet qa1=new QuesAnsSet(1,"Capital of India?","Delhi", "Patna", "Kolkata", "Banglore", "Delhi");
	  QuesAnsSet qa2=new QuesAnsSet(2,"No of States in India?","27", "28", "29", "30", "29");
	  QuesAnsSet qa3=new QuesAnsSet(3,"National Animal?","Lion", "Tiger", "leopard", "cow", "Tiger");
	  QuesAnsSet qa4=new QuesAnsSet(4,"National Bird?","Parrot", "avc", "bcbcb", "Pickok", "Pickok");
	  QuesAnsSet qa5=new QuesAnsSet(5,"National Anthem?","jan gan man", "bande matram", "om jai jag", "no anthem", "jan gan man");
	  creditScoreDAO.save(qa1);creditScoreDAO.save(qa2);creditScoreDAO.save(qa3);
	  creditScoreDAO.save(qa4);creditScoreDAO.save(qa5);
	  
  }
  
  
  
  public void addUsers()
     {
	  UserDetails u1=new UserDetails(101,"shashi ", "bhushan", "shashi@gmail.com","12345", "Admin");
	  UserDetails u2=new UserDetails(102,"bhushan ", "jha", "bhushan@gmail.com","12345", "Candidate");
	  UserDetails u3=new UserDetails(103,"prasad ", "mishra", "prasad@gmail.com","12345", "Candidate");
	  UserDetails u4=new UserDetails(104,"yadav ", "ram", "yadav@gmail.com","12345" ,"Candidate");
	  userDao.save(u1); userDao.save(u2); userDao.save(u3); userDao.save(u4);
	  }
  
  
 
  }
  


	

