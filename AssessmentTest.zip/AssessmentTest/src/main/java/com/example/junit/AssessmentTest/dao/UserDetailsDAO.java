package com.example.junit.AssessmentTest.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.junit.AssessmentTest.Entity.UserDetails;


@Repository
public interface UserDetailsDAO extends JpaRepository<UserDetails, Integer> {
    public  List<UserDetails> findByUserType(String userType);
   
    //@Query("SELECT u FROM UserDetails u WHERE u.email = ? AND u.password = ?")
  public  UserDetails findByEmailAndPassword(String email, String password);

    
}
