package com.bank.app.bankApplication.controllerTest;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.bank.app.bankApplication.controller.CreditCardValidatorController;
import com.bank.app.bankApplication.service.CreditCardValidatorService;

 //imports: MockMvcRequestBuilders.*, MockMvcResultMatchers.*



@RunWith(SpringRunner.class)
@WebMvcTest(CreditCardValidatorController.class)
public class BankControllerTest {
    @Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private CreditCardValidatorService businessService;
	
	@Test
	public void getAccount() throws Exception
	{
		RequestBuilder request=MockMvcRequestBuilders
				               .get("/accountDetails")
				               .accept(MediaType.APPLICATION_JSON);
		MvcResult result=mockMvc.perform(request).andExpect(status().isOk())
				                     .andExpect(content().json("\r\n" + 
				                     		"[{\"accountId\":1,\"accountType\":\"Saving\",\"balance\":9000,\"customer\":{\"customerId\":2,\"customerName\":\"shashi\",\"email\":\"XXXXXXXXXX@GMAIL.COM\",\"address\":\"Banglore\"}},{\"accountId\":3,\"accountType\":\"Current\",\"balance\":14000,\"customer\":{\"customerId\":4,\"customerName\":\"bhushan\",\"email\":\"bhushan@gmail.com\",\"address\":\"Indore\"}},{\"accountId\":5,\"accountType\":\"Current\",\"balance\":25000,\"customer\":{\"customerId\":6,\"customerName\":\"amir\",\"email\":\"amir@gmail.com\",\"address\":\"mumbai\"}},{\"accountId\":7,\"accountType\":\"Current\",\"balance\":11000,\"customer\":{\"customerId\":8,\"customerName\":\"salman\",\"email\":\"salman@gmail.com\",\"address\":\"darbhanga\"}}]",false))
				                     .andReturn();
				                               
	}
	
}
