package com.bank.app.bankApplication.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.bank.app.bankApplication.dao.CreditScoreDAO;
import com.bank.app.bankApplication.entity.CreditCardDetails;

@Service
public class CreditCardValidatorService {
    @Autowired
	private CreditScoreDAO creditScoreDao;
    
    public String saveCreditScoreDetails(CreditCardDetails cardDetails)
    {
    	if(null != cardDetails)
    	{
    		creditScoreDao.save(cardDetails);
    		return "Details Saved Successfully";
    	}
    	
    	else
    	{
    		return "Invalid Request";
    	}
    }


    public  List<CreditCardDetails> getCreditScore( String panCardNo)
    {    
    	
    	
    		 return creditScoreDao.findByPancard(panCardNo);
    	
    }

    
}
