import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Scorelist } from './creditscore/scorelist';
@Injectable({
  providedIn: 'root'
})
export class StudentService {
creditCardJavaEndPoint="http://localhost:2020/getscore/";

constructor(private _http:HttpClient) { }
 
 
getScoreByPAN(pancard:string):Observable<Scorelist>
{
return this._http.get<Scorelist>(this.creditCardJavaEndPoint+pancard);
}

}
