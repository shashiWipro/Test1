export interface Scorelist {
    id?:number;
    pancard?:string;
    creditscore?:number;

}
