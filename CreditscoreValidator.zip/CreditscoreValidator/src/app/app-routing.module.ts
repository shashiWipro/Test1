import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreditscoreComponent } from './student/creditscore/creditscore.component';

const routes: Routes = [
//{path:"create",component:AddStudentComponent},
//{path:"show",component:ShowStudentComponent},
{path:"creditscore",component:CreditscoreComponent},
{path:"**",component:CreditscoreComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
