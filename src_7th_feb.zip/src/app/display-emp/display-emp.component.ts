import { Component, OnInit } from '@angular/core';
import { EmployeeServiceService } from '../employee-service.service';
import { ActivatedRoute, Router } from '@angular/router';
import { IEmployee } from '../IEmployee';

@Component({
  selector: 'app-display-emp',
  templateUrl: './display-emp.component.html',
  styleUrls: ['./display-emp.component.css']
})
export class DisplayEmpComponent implements OnInit {
  employee :IEmployee
  constructor(private _service:EmployeeServiceService,
               private  _activatedRoute:ActivatedRoute,
               private _router:Router) { }

  ngOnInit() {

    this._activatedRoute.paramMap.subscribe(
      (param)=>{
        const empId=+param.get('id');
        if(empId)
        {
          this._service.getEmployee(empId).subscribe(
                (data)=>this.employee=data
            );
        }
        else{
          this.employee = {
             id:null,
             name:'',
             location:'',
             email:'',
             mobile:''

          };
        }
      }    );
  }

  goBack()
  {
    this._router.navigate(['/showStudent']);
  }

}
