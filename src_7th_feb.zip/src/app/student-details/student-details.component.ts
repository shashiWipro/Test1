import { Component, OnInit } from '@angular/core';
import {FormGroup,FormControl} from '@angular/forms';
import {ActivatedRoute} from '@angular/router';
import { from } from 'rxjs';
import { EmployeeServiceService } from '../employee-service.service';
import { IEmployee } from '../IEmployee';
import {Router} from '@angular/router';
@Component({
  selector: 'app-student-details',
  templateUrl: './student-details.component.html',
  styleUrls: ['./student-details.component.css']
})
export class StudentDetailsComponent implements OnInit {
  employeeForm:FormGroup;
  employee:IEmployee;
  constructor(private  _activatedRoute:ActivatedRoute,
              private  _employeeService:EmployeeServiceService,
              private _router:Router) { }

  ngOnInit() {
    this.employeeForm=new FormGroup({
      id:new FormControl(),
      name:new FormControl(),
      location:new FormControl(),
      email:new FormControl(),
      mobile:new FormControl(),
      
    });

    this._activatedRoute.paramMap.subscribe(
      (param)=>{
        const empId=+param.get('id');
        if(empId)
        {
        this.getEmployee(empId);
        }
        else{
          this.employee = {
             id:null,
             name:'',
             location:'',
             email:'',
             mobile:''

          };
        }
      }    );
  }


getEmployee(eid:number)
{
this._employeeService.getEmployee(eid).subscribe(

  (employee:IEmployee)=>{
                       this.editEmployee(employee);
                       this.employee=employee;
                         }

);
}

editEmployee(emp:IEmployee)
{
this.employeeForm.patchValue({
  id:emp.id,
  name:emp.name,
  location:emp.location,
  email:emp.email,
  mobile:emp.mobile

});
}

  onSubmit():void{
    this.MapFormValueToEmployeeModel();
    if(this.employee.id){
    this._employeeService.updateEmployee(this.employee).subscribe(
     ()=>this._router.navigate(['showStudent'])
    );
    }
    else{
      const sid=+(this._employeeService.findMaxEid());
      this.employee.id =(sid+1);
     

      this._employeeService.addEmployee(this.employee).subscribe(
        ()=>this._router.navigate(['showStudent'])
       );
    }
     
  }

MapFormValueToEmployeeModel()
{
  //this.employee.id=this.employeeForm.value.id;
  this.employee.name=this.employeeForm.value.name;
  this.employee.location=this.employeeForm.value.location;
  this.employee.email=this.employeeForm.value.email;
  this.employee.mobile=this.employeeForm.value.mobile;
}

}
