import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeServiceService } from '../employee-service.service';
import { IEmployee } from '../IEmployee';

@Component({
  selector: 'app-show-student',
  templateUrl: './show-student.component.html',
  styleUrls: ['./show-student.component.css']
})
export class ShowStudentComponent implements OnInit {
 employees:IEmployee[];
 employee1:IEmployee;
  constructor(
              private _router:Router,
              private _empService:EmployeeServiceService) {
             
   }

   editButtonClick(employeeId:number)
   {
       this._router.navigate(['/edit',employeeId]);
   }

   displayEmployeeDetails(employeeId:number)
   {
      

      this._router.navigate(['/display',employeeId]);
    
     
   }


   deleteButtonClick(empId:number)
   {
    this._empService.deleteEmployee(empId).subscribe(
      ()=>this._router.navigate(['/showStudent'])
     );
     window.location.reload(true);
   }

  ngOnInit() {
    this._empService.getEmployees().subscribe(
      (listEmployee)=>this.employees=listEmployee
    );

 
  }


   
}
