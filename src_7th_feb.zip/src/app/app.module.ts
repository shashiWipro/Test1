import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ShowStudentComponent } from './show-student/show-student.component';
import { StudentDetailsComponent } from './student-details/student-details.component';
import {ReactiveFormsModule} from '@angular/forms';
import {EmployeeServiceService}from './employee-service.service';

import { HttpClientModule, HttpClient } from '@angular/common/http';
import { FilterDataPipe } from './filter-data.pipe';
import { DisplayEmpComponent } from './display-emp/display-emp.component';
@NgModule({
  declarations: [
    AppComponent,
    ShowStudentComponent,
    StudentDetailsComponent,
    FilterDataPipe,
    DisplayEmpComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [EmployeeServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
