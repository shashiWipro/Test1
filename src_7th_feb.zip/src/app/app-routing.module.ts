import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ShowStudentComponent } from './show-student/show-student.component';
import { StudentDetailsComponent} from './student-details/student-details.component';
import {DisplayEmpComponent} from './display-emp/display-emp.component';
const routes: Routes = [
   {path:'create',component:StudentDetailsComponent},
   {path:'edit/:id',component:StudentDetailsComponent},
   {path:'display/:id',component:DisplayEmpComponent},

   
   {path:'showStudent',component:ShowStudentComponent},
   {path:'**',component:StudentDetailsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
