export interface IEmployee
{   
      id:number;
      name: string;
      location: string;
      email:string;
      mobile:string;
   
}