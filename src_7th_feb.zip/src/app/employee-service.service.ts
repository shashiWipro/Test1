import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Observable} from 'rxjs';
import { IEmployee } from './IEmployee';
import { map } from 'rxjs/operators';
//import { CATCH_ERROR_VAR } from '@angular/compiler/src/output/output_ast';
@Injectable({
  providedIn: 'root'
})
export class EmployeeServiceService {

  constructor(private _httpClient:HttpClient) { }
  employeelist:IEmployee[];
  baseUrl="http://localhost:3000/employees";
  getEmployees():Observable<IEmployee[]>
  {

  return this._httpClient.get<IEmployee[]>(this.baseUrl);
  }

  getEmployee(id:number):Observable<IEmployee>
  {
    
     return this._httpClient.get<IEmployee>(`${this.baseUrl}/${id}`);
  }

  updateEmployee(employee:IEmployee):Observable<void>
  {
return this._httpClient.put<void>(`${this.baseUrl}/${employee.id}`,employee,{
  headers:new HttpHeaders({'Content-Type': 'application/json'})
})
  }

  addEmployee(freshEmployee:IEmployee):Observable<void>
                    {
                      console.log(freshEmployee);
   return this._httpClient.post<void>(this.baseUrl,freshEmployee,{
                             headers:new HttpHeaders(
                               {
                                'Content-Type': 'application/json'
                               }
                             )
                               })
                     }

  findMaxEid():number
                   {
    this.getEmployees().subscribe(
     (listEmployee)=>this.employeelist=listEmployee
            );

            
    const maxId=this.employeelist.reduce(function(e1,e2){
                return (+(e1.id) > +(e2.id))?e1:e2;
                      }).id;  
        console.log(maxId);                                                     
                        return (maxId);
                    } 

getMaxId():number
{
 return Math.max.apply(Math, this.employeelist.map(function(o) { return o.id; }))
}

deleteEmployee(id:number):Observable<void>
{
return this._httpClient.delete<void>(`${this.baseUrl}/${id}`);
window.location.reload(true);

}

                  
}
