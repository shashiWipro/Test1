import { FilterDataPipe } from './filter-data.pipe';

describe('FilterDataPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterDataPipe();
    expect(pipe).toBeTruthy();
  });
});
