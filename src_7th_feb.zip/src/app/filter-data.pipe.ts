import { Pipe, PipeTransform } from '@angular/core';
import { IEmployee } from './IEmployee';

@Pipe({
  name: 'filterData'
})
export class FilterDataPipe implements PipeTransform {

  transform(employees: IEmployee[], value: string, label:string): IEmployee[] {
    if (!employees) return [];
    if (!value) return  employees;
    if (value == '' || value == null) return [];
    return employees.filter(e => e[label].indexOf(value) > -1 );
    
  }

}
