package com.bank.app.bankApplication.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bank.app.bankApplication.entity.Customer;

public interface CustomerDAO extends JpaRepository<Customer, Integer>{

}
