package com.bank.app.bankApplication.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bank.app.bankApplication.entity.Account;
import com.bank.app.bankApplication.service.BankService;

@RestController
public class BankController {

@Autowired
private BankService bankService;



@GetMapping(value = "/accountDetails")
public List<Account> getAccount()
   {
	return bankService.getAccount();
   }




@GetMapping("/account/{id}")
public Account getByAccountId(@PathVariable Integer id)
   {
return bankService.findAccountById(id);
   }




@GetMapping("/transfer/{fromAcc}/{toAcc}/{ammount}")
public String fundTransfer(@PathVariable Integer fromAcc,@PathVariable Integer toAcc,@PathVariable Integer ammount)
{
	return bankService.transferBalance(fromAcc, toAcc, ammount);
}





@GetMapping("/balance/{accountNo}")
public Integer getBalance(@PathVariable Integer accountNo)
{
	return bankService.getAccount(accountNo).getBalance();
}





@PutMapping("/updateacc/{accno}/{account}")
public void updateAccount(@PathVariable Integer accno,@RequestBody Account account)
{
	bankService.updateData(accno, account);
}






@DeleteMapping("/deleteacc/{accountno}")
public String deleteAccount(@PathVariable Integer accountno)
     {
	return bankService.deleteAccount(accountno);
     }





@PostMapping("/savedetails/{accountdetails}")
public String saveAccountDetails(@RequestBody Account accountdetails)
{
	 return  bankService.saveAccountDetails(accountdetails);
}





}
