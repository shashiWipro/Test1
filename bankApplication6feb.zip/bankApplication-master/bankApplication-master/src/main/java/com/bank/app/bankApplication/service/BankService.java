package com.bank.app.bankApplication.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bank.app.bankApplication.dao.AccountDAO;
import com.bank.app.bankApplication.entity.Account;
import com.bank.app.bankApplication.entity.Customer;

@Service
public class BankService {
	@Autowired
	private AccountDAO accDAO;	
	
	
	public List<Account> getAccount()
	{
		return accDAO.findAll();
	}
	
	public Account findAccountById(Integer id)
	{
		return accDAO.findById(id).get();
	}
	
	
	
	public String transferBalance(Integer fromAccount,Integer toAccount,Integer ammount)
	{

		Account fromAccountDetails = getAccount(fromAccount);
		Account toAccountDetails = getAccount(toAccount);
		if((fromAccountDetails.getBalance()>500) && (fromAccountDetails.getBalance()-ammount)>500)
		{
			toAccountDetails.setBalance(toAccountDetails.getBalance() + ammount);
			fromAccountDetails.setBalance(fromAccountDetails.getBalance() - ammount);

			accDAO.save(fromAccountDetails);
			accDAO.save(toAccountDetails);
			return "Ammount Transfered Succesfully";
		}
		else
		{
		
		return "You do not have Enough Balance to Transfer";
		}
	}
	
	

	 public void  updateData(Integer id,Account account) 
	          {
		 System.out.println("************updateData****************");
	    Optional<Account> ac =accDAO.findById(id);
		 Account ac1=ac.get();
		System.out.println(ac1);
	    System.out.println(ac);
	    
	    if(account.getAccountType()!=null)
	    	  ac1.setAccountType(account.getAccountType());
	  
	    if(account.getCustomer().getEmail()!=null)
			ac1.getCustomer().setEmail(account.getCustomer().getEmail());
	    
	    if(account.getCustomer().getCustomerName()!=null)
			ac1.getCustomer().setCustomerName(account.getCustomer().getCustomerName());
	    
	    
		accDAO.save(ac1);
	  }
	
	
	
	 public  Account getAccount(Integer inputAccountId)
         {
	 Optional<Account> ac=accDAO.findById(inputAccountId);
	 return ac.get();
        }
	 
	 
	 public String deleteAccount(Integer accountNo)
	 {
		 if(null!=accountNo)
		 {
		 accDAO.deleteById(accountNo);
		 return "Account Deleted Successfully";
		 }
		 
		 else
		 {
			 return "There is Nothing to delete";
		 }
	 }
	
	 
	 
	 public String  saveAccountDetails(Account account)
	 {
		 if(null!=account)
		 {
           accDAO.save(account);
           return "Account Details Saved Successfully";
		 }
	     
		 else
		 {
		return "Account Details is Not Valid";
		 }
	 }
}
