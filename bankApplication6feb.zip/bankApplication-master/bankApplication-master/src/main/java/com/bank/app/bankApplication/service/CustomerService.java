package com.bank.app.bankApplication.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bank.app.bankApplication.dao.CustomerDAO;
import com.bank.app.bankApplication.entity.Customer;

@Service
public class CustomerService {

	   
	@Autowired
	private CustomerDAO customerDao;
	
	
	public List<Customer> getCustomerDetails()
	{
		return customerDao.findAll();
	}
	
	
	
	public Customer getCustomerById( Integer customerId)
	{
		return customerDao.findById(customerId).get();
	}
	

	public String  deleteCustomerById( Integer customerId)
	{
		if(null != customerId)
		{
			 customerDao.deleteById(customerId);
			 return "Customer Details Deleted Successfully";
		}
		
		else
		{
			return "Not A Valid Request";
		}
	}
	
	
	public String saveCustomer(Customer customer)
	{
		  if(null != customer)
		  {
			  customerDao.save(customer);
			  return "Customer Details Saved Successfully";
		  }
		  else
		  {
			  return "Not A valid Customer Details";
		  }
	}
	

}
