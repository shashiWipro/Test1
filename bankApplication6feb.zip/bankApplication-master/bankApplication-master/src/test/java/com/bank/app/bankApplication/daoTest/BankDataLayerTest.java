package com.bank.app.bankApplication.daoTest;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.bank.app.bankApplication.dao.AccountDAO;
import com.bank.app.bankApplication.entity.Account;

@RunWith(SpringRunner.class)
@DataJpaTest
public class BankDataLayerTest {
    
	@Autowired
	private AccountDAO accountDao;
	
	@Test
	public void testFindAllSize()
	{
	List<Account> accountList=accountDao.findAll();
	assertEquals(4,accountList.size());
	}
	
	@Test
	public void findOneAccountDetailsTest()
	{
	List<Account> accounts=accountDao.findByAccountType("Saving");
	System.out.println(accounts);
	assertEquals(true, accounts.isEmpty());
	}
	
	
	
	  @Test public void testFindAllContains() { 
		  List<Account>
	  accountList=accountDao.findAll(); System.out.println(accountList.get(0));
	  assertEquals("Saving",accountList.get(0));
	  
	  }
	 
}
