package com.bank.app.bankApplication.business;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.bank.app.bankApplication.dao.AccountDAO;
import com.bank.app.bankApplication.entity.Account;
import com.bank.app.bankApplication.service.BankService;

@RunWith(MockitoJUnitRunner.class)
public class BankBusinessLayerTest {
     
	@InjectMocks
	private BankService service;
	
	@Mock
	private AccountDAO accountDao;
	
	@Test
	private void serviceTest_basic()
	{
     String expected=service.transferBalance(1, 3, 50);	
    assertEquals("Ammount Transfered Succesfully", expected);
    
    
    when(service.transferBalance(1, 3, 50)).thenReturn("Ammount Transfered Succesfully");
	}
	
	
	
	@Test
	private void serviceTest_basic_size()
	{
     List<Account> expected=service.getAccount();	
     assertEquals(4, expected);
    
	}
	
	
	
	

	@Test
	private void serviceTest_basic_getAcc()
	{
     Account expected=service.findAccountById(4);	
     assertEquals("Saving", expected.getAccountType());
    
	}
	
	
	
	
	
	
}
